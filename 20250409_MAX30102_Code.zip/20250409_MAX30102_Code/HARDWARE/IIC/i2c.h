#ifndef __I2C_H
#define __I2C_H			 
#include "delay.h"

/**********************
���ű�������
***********************/			
//sbit	SDA	= P4^1;	//����SDA  
//sbit	SCL	= P4^2;	//����SCL
#define SCL    PBout(10) //SCL
#define SDA    PBout(11) //SDA	 
#define READ_SDA    PBin(11) //SDA	

#define SDA_IN()  {GPIOB->CRH&=0XFFFF0FFF;GPIOB->CRH|=0x08<<12;}
#define SDA_OUT() {GPIOB->CRH&=0XFFFF0FFF;GPIOB->CRH|=0x03<<12;}


/* Private function prototypes -----------------------------------------------*/
void I2C_delay(void);
u8 I2C_start(void);
void I2C_Stop(void);
void I2C_NoAck(void);
u8 I2C_WaitAck(void) ;
void I2C_SendByte(u8 SendByte) ;
u8 I2C_ReceiveByte(void)  ;
void I2C_Ack(u8 a);
u8 IIC_Write_Byte(u8 device_addr,u8 register_addr,u8 dat);
u8 IIC_Receive_Byte(void);
u8 IIC_Read_Byte(u8 device_addr,u8 register_addr);
u8 IIC_Read_Array(u8 device_addr,u16 register_addr,u8 *Data,u16 Num);
void IIC_Init(void);
#endif 

