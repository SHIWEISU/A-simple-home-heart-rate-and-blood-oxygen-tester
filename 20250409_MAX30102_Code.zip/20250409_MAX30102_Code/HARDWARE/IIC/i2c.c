
//ͷ�ļ�
#include "i2c.h"
#include "delay.h"

 /**
  * @file   I2C_delay
  * @brief  �ӳ�ʱ��
  * @param  ��
  * @retval ��
  */
	int ack=2;
void I2C_delay(void)  //for 1T  STC	delay 
{
	u16 j,i=1;   
//	for(j=0;j<18;j++)   
//	{    
//		for(i=0;i<7;i++);   
//	}
		while(i--);
}

 /**
  * @file   I2C_Start
  * @brief  ��ʼ�ź�
  * @param  ��
  * @retval ��
  */
u8 I2C_Start(void)
{
	SDA_OUT();
	SCL = 1;
	SDA = 1;
	I2C_delay();
	SDA = 0;
	I2C_delay();
	SCL = 0;
	I2C_delay();
	return 1;
}

 /**
  * @file   I2C_Stop
  * @brief  ֹͣ�ź�
  * @param  ��
  * @retval ��
  */
void I2C_Stop(void)
{
	SDA_OUT();
	SDA=0;
	SCL = 1;
	I2C_delay();
	SDA = 1;
	I2C_delay();
}

 /**
  * @file   I2C_Ack
  * @brief  Ӧ���ź�
  * @param  ��
  * @retval ��
  */


 /**
  * @file   I2C_NoAck
  * @brief  ��Ӧ���ź�
  * @param  ��
  * @retval ��
  */
void I2C_NoAck(void)
{	
	SCL = 0;
	I2C_delay();
	SDA = 1;
	I2C_delay();
	SCL = 1;
	I2C_delay();
	SCL = 0;
	I2C_delay();
}

 /**
  * @file   I2C_WaitAck
  * @brief  �ȴ�Ack
  * @param  ��
  * @retval ����Ϊ:=1��ACK,=0��ACK
  */
u8 I2C_WaitAck(void) 	
{
	SCL = 0;
	I2C_delay();
	SDA = 1;			
	I2C_delay();
	SCL = 1;
	I2C_delay();
	if(READ_SDA)
	{
      SCL = 0;
      return 0;
	}
	SCL = 0;
	return 1;
}

 /**
  * @file   I2C_SendByte
  * @brief  ���ݴӸ�λ����λ
  * @param  - SendByte: ���͵�����
  * @retval ��
  */
u8 I2C_Send_Byte(u8 SendByte) 
{
    u8 i=8,cnt=200;
	
	SDA_OUT();
	SCL = 0;

//    while(i--)
//    {
//			if(SendByte&0x80)
//			SDA = 1;  
//			else 
//			SDA = 0;
//			SendByte<<=1;
//			I2C_delay();
//			SCL=1;		
//			I2C_delay();
//			SCL=0;
//			I2C_delay();
//			
//    }
	
	 do
    {
        if (SendByte&0x80)
        {
            SDA=1;
        }
        else
        {
            SDA=0;
        }

        SendByte<<=1;
    //delay_us(2);
				I2C_delay();
        SCL=1;
    //delay_us(2);
				I2C_delay();
        SCL=0;
    //delay_us(2);
				I2C_delay();
    }
    while(--i);
		
		I2C_delay();
//		SDA_IN();
		SCL=1;
		I2C_delay();
		
		
//    SDA = 1;
//		I2C_delay();
		
//		while(cnt--)
//		{
//			if(SDA==1)
//        ack=1;
//			else
//			{
//				ack=0;
//				break;
//			}				
//		}
		do
    {
        if(!SDA)
        {
            ack = 0;
            break;
        }
    }
    while (--cnt);
		
		SCL=0;
		I2C_delay();
//		return 0;
}


 /**
  * @file   I2C_ReceiveByte
  * @brief  ���ݴӸ�λ����λ
  * @param  ��
  * @retval I2C���߷��ص�����
  */
u8 I2C_ReceiveByte(void)  
{ 
    u8 i=8;
    u8 ReceiveByte=0;		
	
//    while(i--)
//    {
//      ReceiveByte<<=1;     
//			SDA_OUT();
//      SCL = 1;
//      I2C_delay();
//			SDA_IN();
//			if(READ_SDA==1)
//				ReceiveByte++;
//	    SCL = 0;
//      I2C_delay();	

//    }
	
	SDA_IN();
   // delay_us(2);
	I2C_delay();
    SDA=1;

    do
    {
//			SDA_OUT();//SDA����Ϊ���
        SCL=1;
    //delay_us(2);
			I2C_delay();
			//
        ReceiveByte <<= 1;
        if(READ_SDA)
        {
            ReceiveByte |= 0x01;
        }
    //delay_us(2);
				I2C_delay();
        SCL=0;
   // delay_us(2);
				I2C_delay();
    }
    while(--i);

		
		
    return ReceiveByte;
} 
u8 IIC_Write_Byte(u8 device_addr,u8 register_addr,u8 dat)
{
	SDA_OUT();
	I2C_Start();
	I2C_Send_Byte(device_addr+0);
	if (ack==1)
		return 0;
	delay_us(5);
	I2C_Send_Byte(register_addr);   
	if (ack==1)
		return 0;
	delay_us(5);
	I2C_Send_Byte(dat);
	if (ack==1)
		return 0; 
	delay_us(5);
	I2C_Stop();
	return 1;
}
void I2C_Ack(u8 a)
{ 
	SCL=0; 
	SDA_OUT();
	if(a)
	{
		SDA=1;            //��Ӧ��
      I2C_delay();
		SCL=1;  	
      I2C_delay();
		SCL=0; 	
      I2C_delay();
	}
	else
	{
		SDA=0; 						//Ӧ��
      I2C_delay();
		SCL=1;  
      I2C_delay();
		SCL=0; 
      I2C_delay();
//		SDA=1; 
	}
}
u8 IIC_Read_Byte(u8 device_addr,u8 register_addr)
{
	u8 read_data;
	I2C_Start();
	I2C_Send_Byte(device_addr+0);
	if (ack==1)return 0;
	I2C_Send_Byte(register_addr);
	if (ack==1)return 0;
	I2C_Start();
	I2C_Send_Byte(device_addr+1);
	if (ack==1)return 0;
	read_data = I2C_ReceiveByte();
	I2C_Ack(1);
	I2C_Stop();
	return read_data;
}
u8 IIC_Read_Array(u8 device_addr,u16 register_addr,u8 *Data,u16 Num)
{
	u16 i;
	I2C_Start();
	I2C_Send_Byte(device_addr+0);
	if (ack==1)return 0;
	I2C_Send_Byte(register_addr);
	if (ack==1)return 0;
	delay_us(5);
	I2C_Start();
	I2C_Send_Byte(device_addr+1);
	if (ack==1)return 0;
	for(i=0;i<Num;i++)
	{
		*Data++ = I2C_ReceiveByte();
		if(i==Num-1)
			I2C_Ack(1);
		else
			I2C_Ack(0);
	}
	I2C_Stop();
	return 1;
}
void IIC_Init(void)
{
//	GPIO_InitTypeDef GPIO_InitStructure;
//	RCC_APB2PeriphClockCmd(	RCC_APB2Periph_GPIOB, ENABLE );	//ʹ��GPIOBʱ��
//	   
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD ;   //
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//	GPIO_Init(GPIOB, &GPIO_InitStructure);
//	GPIO_SetBits(GPIOB,GPIO_Pin_10); 	//
//	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD ;   //
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//	GPIO_Init(GPIOB, &GPIO_InitStructure);
//	GPIO_SetBits(GPIOB,GPIO_Pin_11);
	
	GPIO_InitTypeDef  GPIO_InitStructure;
 	
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	
	
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;				 
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOB, &GPIO_InitStructure);					 
 GPIO_SetBits(GPIOB,GPIO_Pin_10);						

 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;	    		
 GPIO_Init(GPIOB, &GPIO_InitStructure);	  				 
 GPIO_SetBits(GPIOB,GPIO_Pin_11); 						
}


/*********************************END FILE********************************************/	
